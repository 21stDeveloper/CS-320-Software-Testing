import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testTaskConstructorValid() {
        Task t = new Task("12345", "Wash car", "Wash and vacuum the car.");
        assertEquals("12345", t.getTaskId());
        assertEquals("Wash car", t.getName());
        assertEquals("Wash and vacuum the car.", t.getDescription());
    }

    @Test
    void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc"));
    }

    @Test
    void testTaskIdCannotBeTooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Desc"));
    }

    @Test
    void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Desc"));
    }

    @Test
    void testNameCannotBeTooLong() {
        String longName = "123456789012345678901"; // 21
        assertThrows(IllegalArgumentException.class, () -> new Task("1", longName, "Desc"));
    }

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", null));
    }

    @Test
    void testDescriptionCannotBeTooLong() {
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", longDesc));
    }

    @Test
    void testSetNameValid() {
        Task t = new Task("1", "Old", "Desc");
        t.setName("New");
        assertEquals("New", t.getName());
    }

    @Test
    void testSetDescriptionValid() {
        Task t = new Task("1", "Name", "Old");
        t.setDescription("New description");
        assertEquals("New description", t.getDescription());
    }

    @Test
    void testSetNameInvalid() {
        Task t = new Task("1", "Name", "Desc");
        assertThrows(IllegalArgumentException.class, () -> t.setName(null));
        assertThrows(IllegalArgumentException.class, () -> t.setName("123456789012345678901")); // 21
    }

    @Test
    void testSetDescriptionInvalid() {
        Task t = new Task("1", "Name", "Desc");
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> t.setDescription("123456789012345678901234567890123456789012345678901")); // 51
    }
}
