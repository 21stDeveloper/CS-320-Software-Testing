package contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    void testContactCreatesWithValidData() {
        Contact c = new Contact("12345", "Ariel", "Chavarria", "5125551234", "123 Main St");
        assertEquals("12345", c.getContactId());
        assertEquals("Ariel", c.getFirstName());
        assertEquals("Chavarria", c.getLastName());
        assertEquals("5125551234", c.getPhone());
        assertEquals("123 Main St", c.getAddress());
    }

    @Test
    void testInvalidContactIdNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact(null, "Ariel", "Chavarria", "5125551234", "123 Main St")
        );
    }

    @Test
    void testInvalidContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345678901", "Ariel", "Chavarria", "5125551234", "123 Main St")
        );
    }

    @Test
    void testInvalidFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", null, "Chavarria", "5125551234", "123 Main St")
        );
    }

    @Test
    void testInvalidFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "01234567890", "Chavarria", "5125551234", "123 Main St")
        );
    }

    @Test
    void testInvalidPhoneNot10Digits() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Ariel", "Chavarria", "123", "123 Main St")
        );
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Ariel", "Chavarria", "ABCDEFGHIJ", "123 Main St")
        );
    }

    @Test
    void testInvalidAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
            new Contact("12345", "Ariel", "Chavarria", "5125551234",
                "0123456789012345678901234567890") // 31 chars
        );
    }
}
