package app;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 3_600_000); // +1 hour
    }

    @Test
    void testAddAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("A1", futureDate(), "Dentist");

        service.addAppointment(appt);

        assertNotNull(service.getAppointment("A1"));
        assertEquals("Dentist", service.getAppointment("A1").getDescription());
    }

    @Test
    void testAddAppointmentDuplicateIdFails() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(new Appointment("A1", futureDate(), "First"));

        assertThrows(IllegalArgumentException.class, () ->
                service.addAppointment(new Appointment("A1", futureDate(), "Second")));
    }

    @Test
    void testDeleteAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(new Appointment("A1", futureDate(), "Dentist"));

        service.deleteAppointment("A1");

        assertNull(service.getAppointment("A1"));
    }

    @Test
    void testDeleteAppointmentMissingIdFails() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("NOPE"));
    }

    @Test
    void testDeleteAppointmentNullFails() {
        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
    }
}
