import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddTaskSuccess() {
        TaskService service = new TaskService();
        Task t = new Task("A1", "Task", "Description");
        service.addTask(t);

        Task fetched = service.getTask("A1");
        assertNotNull(fetched);
        assertEquals("Task", fetched.getName());
    }

    @Test
    void testAddTaskDuplicateIdFails() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Task1", "Desc1"));
        assertThrows(IllegalArgumentException.class, () ->
            service.addTask(new Task("A1", "Task2", "Desc2"))
        );
    }

    @Test
    void testDeleteTaskSuccess() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Task", "Desc"));
        service.deleteTask("A1");
        assertNull(service.getTask("A1"));
    }

    @Test
    void testDeleteTaskNotFoundFails() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("NOPE"));
    }

    @Test
    void testUpdateNameSuccess() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "OldName", "Desc"));
        service.updateName("A1", "NewName");
        assertEquals("NewName", service.getTask("A1").getName());
    }

    @Test
    void testUpdateDescriptionSuccess() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Name", "OldDesc"));
        service.updateDescription("A1", "NewDesc");
        assertEquals("NewDesc", service.getTask("A1").getDescription());
    }

    @Test
    void testUpdateNotFoundFails() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.updateName("NOPE", "Name"));
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("NOPE", "Desc"));
    }

    @Test
    void testUpdateNameInvalidFails() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> service.updateName("A1", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateName("A1", "123456789012345678901")); // 21
    }

    @Test
    void testUpdateDescriptionInvalidFails() {
        TaskService service = new TaskService();
        service.addTask(new Task("A1", "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("A1", null));
        assertThrows(IllegalArgumentException.class, () ->
            service.updateDescription("A1", "123456789012345678901234567890123456789012345678901") // 51
        );
    }
}
