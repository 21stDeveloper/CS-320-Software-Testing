import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }
        String id = task.getTaskId();
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task ID already exists: " + id);
        }
        tasks.put(id, task);
    }

    public void deleteTask(String taskId) {
        if (taskId == null || taskId.trim().isEmpty()) {
            throw new IllegalArgumentException("Task ID cannot be null/empty.");
        }
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found: " + taskId);
        }
        tasks.remove(taskId);
    }

    public void updateName(String taskId, String newName) {
        Task task = getExistingTask(taskId);
        task.setName(newName);
    }

    public void updateDescription(String taskId, String newDescription) {
        Task task = getExistingTask(taskId);
        task.setDescription(newDescription);
    }

    // Helper + nice for tests
    public Task getTask(String taskId) {
        if (taskId == null || taskId.trim().isEmpty()) {
            throw new IllegalArgumentException("Task ID cannot be null/empty.");
        }
        return tasks.get(taskId);
    }

    private Task getExistingTask(String taskId) {
        if (taskId == null || taskId.trim().isEmpty()) {
            throw new IllegalArgumentException("Task ID cannot be null/empty.");
        }
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found: " + taskId);
        }
        return task;
    }
}
