package contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    void testAddContactSuccess() {
        ContactService service = new ContactService();
        Contact c = new Contact("1", "Ariel", "C", "5125551234", "123 Main St");
        service.addContact(c);
        assertNotNull(service.getContact("1"));
    }

    @Test
    void testAddContactDuplicateIdFails() {
        ContactService service = new ContactService();
        service.addContact(new Contact("1", "Ariel", "C", "5125551234", "123 Main St"));
        assertThrows(IllegalArgumentException.class, () ->
            service.addContact(new Contact("1", "John", "D", "5125559999", "456 Oak Ave"))
        );
    }

    @Test
    void testDeleteContactSuccess() {
        ContactService service = new ContactService();
        service.addContact(new Contact("1", "Ariel", "C", "5125551234", "123 Main St"));
        service.deleteContact("1");
        assertNull(service.getContact("1"));
    }

    @Test
    void testDeleteContactNotFoundFails() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999"));
    }

    @Test
    void testUpdateContactSuccess() {
        ContactService service = new ContactService();
        service.addContact(new Contact("1", "Ariel", "C", "5125551234", "123 Main St"));

        service.updateContact("1", "Ari", null, "5125550000", "New Address");
        Contact updated = service.getContact("1");

        assertEquals("Ari", updated.getFirstName());
        assertEquals("C", updated.getLastName()); // unchanged
        assertEquals("5125550000", updated.getPhone());
        assertEquals("New Address", updated.getAddress());
    }

    @Test
    void testUpdateContactInvalidPhoneFails() {
        ContactService service = new ContactService();
        service.addContact(new Contact("1", "Ariel", "C", "5125551234", "123 Main St"));

        assertThrows(IllegalArgumentException.class, () ->
            service.updateContact("1", null, null, "123", null)
        );
    }

    @Test
    void testUpdateContactNotFoundFails() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () ->
            service.updateContact("999", "A", null, null, null)
        );
    }
}
