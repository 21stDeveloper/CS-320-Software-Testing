package app;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 3_600_000); // +1 hour
    }

    @Test
    void testAppointmentCreationSuccess() {
        Appointment appt = new Appointment("A123", futureDate(), "Annual checkup");
        assertEquals("A123", appt.getAppointmentId());
        assertNotNull(appt.getAppointmentDate());
        assertEquals("Annual checkup", appt.getDescription());
    }

    @Test
    void testAppointmentIdNull() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate(), "Desc"));
    }

    @Test
    void testAppointmentIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate(), "Desc"));
    }

    @Test
    void testAppointmentDateNull() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A123", null, "Desc"));
    }

    @Test
    void testAppointmentDateInPast() {
        Date past = new Date(System.currentTimeMillis() - 3_600_000); // -1 hour
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A123", past, "Desc"));
    }

    @Test
    void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A123", futureDate(), null));
    }

    @Test
    void testDescriptionTooLong() {
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51 chars
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A123", futureDate(), longDesc));
    }
}
