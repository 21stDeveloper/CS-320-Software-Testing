package contact;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }
        String id = contact.getContactId();
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(id, contact);
    }

    public void deleteContact(String contactId) {
        if (contactId == null) {
            throw new IllegalArgumentException("contactId cannot be null");
        }
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.remove(contactId);
    }

    // One update method with optional fields (null = don't change)
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contactId == null) {
            throw new IllegalArgumentException("contactId cannot be null");
        }
        Contact c = contacts.get(contactId);
        if (c == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }

        if (firstName != null) c.setFirstName(firstName);
        if (lastName != null) c.setLastName(lastName);
        if (phone != null) c.setPhone(phone);
        if (address != null) c.setAddress(address);
    }

    // Helpful for testing (not required, but makes tests simple)
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
